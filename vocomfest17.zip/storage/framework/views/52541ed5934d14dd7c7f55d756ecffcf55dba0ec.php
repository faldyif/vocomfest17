<?php $__env->startSection('title', 'Vocomfest - ACM ICPC'); ?>

<?php $__env->startSection('body'); ?>
<section id="news-cover">
	<div class="overlay bk-overlay">
		<div class="news-container">
			<div class="news-desc">
				<h2 class="news-title"><?php echo e($news->title); ?></h2>
				<hr class="bl-line-sep">
				<p class="news-date big"><?php echo e($news->created_at->format('F jS, Y')); ?></p>
			</div>
		</div>
	</div>
	<img src="<?php echo e(url('storage/news_thumbs')); ?>/<?php echo e($news->thumbnail); ?>" class="cover-img">
</section>
<section id="news-body">
	<div class="container pd-bt-20">
		<div class="row pd-bt-20">
			<div class="col-md-10 col-md-offset-1 text-justify">
				<?php echo $news->content; ?>

			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>