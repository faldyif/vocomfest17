<?php $__env->startSection('title', 'Vocomfest - Payment Confirmation'); ?>

<?php $__env->startSection('body'); ?>
<section id="aside" class="col-md-2 col-sm-2 nopad">
	<div id="logo" class="pd-20">
		<div class="row force-center">
			<a href="<?php echo e(url('adminvocomfest17')); ?>">
				<img src="<?php echo e(url('assets/img/logoDb.png')); ?>" alt="Vocomfest">
			</a>
		</div>
	</div>
	<div id="bAside" class="pd-bt-20">
		<div id="user" class="text-center mg-b-20 pd-20">
			<div class="users-icon sep-title">
				<i class="fa fa-users"></i>
			</div>
			<h3>Administrator</h3>
			<hr class="line-db">
			<span>Hello, </span>
			<h4 class="nomag"><?php echo e(Auth::user()->name); ?></h4>
		</div>
		<!-- nav -->
		<div id="navigation">
			<nav class="navbar navbar-default navbar-default-blue">
			  <div class="container-fluid nopad">
			    <div class="navbar-header">
			      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#asideNav">
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>                        
			      </button>
			    </div>
			    <div class="collapse navbar-collapse nopad" id="asideNav">
			      <ul class="nav nav-db">
					<li><a href="<?php echo e(url('adminvocomfest17')); ?>"><i class="fa fa-dashboard"></i><span>Dashboard</span></a></li>
					<li><a href="<?php echo e(url('adminvocomfest17/team')); ?>"><i class="fa fa-users"></i><span>Teams</span></a></li>
					<!-- <li><a href="#"><i class="fa fa-microphone"></i><span>Events</span></a></li> -->
					<li><a href="<?php echo e(url('adminvocomfest17/news')); ?>"><i class="fa fa-hourglass-half"></i><span>News</span></a></li>
					<li><a href="<?php echo e(url('adminvocomfest17/gallery')); ?>"><i class="fa fa-camera"></i><span>Gallery</span></a></li>
					<li class="active"><a href="<?php echo e(url('adminvocomfest17/payment')); ?>"><i class="fa fa-credit-card-alt"></i><span>Payments</span></a></li>
					<li><a href="<?php echo e(url('adminvocomfest17/submission')); ?>"><i class="fa fa-upload"></i><span>Uploads</span></a></li>
				</ul>
			    </div>
			  </div>
			</nav>
		</div>
		<!-- /nav -->
	</div>
</section>
<section id="content" class="col-md-10 col-sm-10 nopad">
	<header class="header-db">
		<img src="../assets/img/event-cover.jpg" alt="Payment" class="cover-img">
		<div class="overlay bk-gr-overlay"  style=""></div>
		<section class="header-text">
			<div class="top-header">
				<span>Hello, <?php echo e(Auth::user()->name); ?> | <a class="a-fa" href="<?php echo e(url('/logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="fa fa-sign-out"></i> Logout</a>
	        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
	            <?php echo e(csrf_field()); ?>

	        </form>
				</span>
			</div>
			<h2 class="mont-bold">Payment</h2>
			<hr class="bl-line-sep">
		</section>
	</header>
	<!-- NEWS CONTENT -->
	<div class="content-db">

<?php if(Session::has('message')): ?>
<div class="row">
    <div class="alert alert-success">
        <div class="sb-msg"><i class="icon-thumbs-up"></i><?php echo e(Session::get('message')); ?></div>
    </div>
</div>
<?php endif; ?>
		<div class="row">
			<section id="pay">
				<div class="col-md-12 pd-15">
					<div class="sec-content-db">
						<div class="div-content-db">
							<form>
								<div class="panel panel-default">
									<div class="panel-heading">
										All payments
									</div>
									<div class="panel-body">
			                            <table class="table table-bordered table-striped table-hover">
			                            	<thead>
			                            		<tr>
			                            			<th>No</th>
			                            			<th>Nama Tim</th>
			                            			<th>Kategori</th>
			                            			<th class="col-md-3">Bukti Bayar</th>
			                            			<th>Aksi</th>
			                            		</tr>
			                            	</thead>
			                            	<tbody>
			                            		<?php $it = 1; ?>
			                            		<?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			                            		<?php if(\App\User::where('id', $key->user_id)->first()->progress == 1): ?>
			                            		<tr>
			                            			<td><?php echo e($it++); ?></td>
			                            			<td><?php echo e(\App\User::where('id', $key->user_id)->first()->name); ?></td>
			                            			<td><?php echo e(\App\User::where('id', $key->user_id)->first()->getKategori()); ?></td>
			                            			<td>
			                            				<a href="<?php echo e(url('storage/payment_proofs')); ?>/<?php echo e($key->proof); ?>" data-rel="lightcase">
															<img src="<?php echo e(url('storage/payment_proofs')); ?>/<?php echo e($key->proof); ?>" class="cover-img">
														</a>
			                            			</td>
			                            			<td>
			                            				<a href="<?php echo e(url('adminvocomfest17/payment/confirm')); ?>/<?php echo e($key->id); ?>" class="btn btn-success btn-sm" alt="Confirm Payment"><i class="fa fa-check"></i></a>
														<a href="<?php echo e(url('storage/payment_proofs')); ?>/<?php echo e($key->proof); ?>" data-rel="lightcase" class="btn btn-primary btn-sm"><i class="fa fa-eye"></i></a>
														<a href="<?php echo e(url('adminvocomfest17/payment/delete')); ?>/<?php echo e($key->id); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
			                            			</td>
			                            		</tr>
			                            		<?php endif; ?>
			                            		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			                            	</tbody>
			                            </table>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</section>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>