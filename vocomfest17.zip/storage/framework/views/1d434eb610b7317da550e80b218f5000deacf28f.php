<?php $__env->startSection('title', 'Vocomfest - SemnasVerifier™'); ?>

<?php $__env->startSection('body'); ?>
<section id="aside" class="col-md-2 col-sm-2 nopad">
	<div id="logo" class="pd-20">
		<div class="row force-center">
			<a href="<?php echo e(url('adminvocomfest17')); ?>">
				<img src="<?php echo e(url('assets/img/logoDb.png')); ?>" alt="Vocomfest">
			</a>
		</div>
	</div>
	<div id="bAside" class="pd-bt-20">
		<div id="user" class="text-center mg-b-20 pd-20">
			<div class="users-icon sep-title">
				<i class="fa fa-users"></i>
			</div>
			<h3>Administrator</h3>
			<hr class="line-db">
			<span>Hello, </span>
			<h4 class="nomag"><?php echo e(Auth::user()->name); ?></h4>
		</div>
		<!-- nav -->
		<div id="navigation">
			<nav class="navbar navbar-default navbar-default-blue">
			  <div class="container-fluid nopad">
			    <div class="navbar-header">
			      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#asideNav">
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>                        
			      </button>
			    </div>
			    <div class="collapse navbar-collapse nopad" id="asideNav">
			      <ul class="nav nav-db">
					<li><a href="<?php echo e(url('adminvocomfest17')); ?>"><i class="fa fa-dashboard"></i><span>Dashboard</span></a></li>
					<li class="active"><a href="<?php echo e(url('adminvocomfest17/team')); ?>"><i class="fa fa-users"></i><span>Teams</span></a></li>
					<!-- <li><a href="#"><i class="fa fa-microphone"></i><span>Events</span></a></li> -->
					<li><a href="<?php echo e(url('adminvocomfest17/news')); ?>"><i class="fa fa-hourglass-half"></i><span>News</span></a></li>
					<li><a href="<?php echo e(url('adminvocomfest17/gallery')); ?>"><i class="fa fa-camera"></i><span>Gallery</span></a></li>
					<li><a href="<?php echo e(url('adminvocomfest17/payment')); ?>"><i class="fa fa-credit-card-alt"></i><span>Payments</span></a></li>
					<li><a href="<?php echo e(url('adminvocomfest17/submission')); ?>"><i class="fa fa-upload"></i><span>Uploads</span></a></li>
				</ul>
			    </div>
			  </div>
			</nav>
		</div>
		<!-- /nav -->
	</div>
</section>
<section id="content" class="col-md-10 col-sm-10 nopad">
	<header class="header-db">
		<img src="<?php echo e(url('assets/img/event-cover.jpg')); ?>" alt="News Vocomfest" class="cover-img">
		<div class="overlay bk-gr-overlay"  style=""></div>
		<section class="header-text">
			<div class="top-header">
				<span>Hello, Administrator Name | <a class="a-fa" href="./login.html"><i class="fa fa-sign-out"></i> Logout</a></span>
			</div>
			<h2 class="mont-bold">SemnasVerifier™</h2>
			<hr class="bl-line-sep">
		</section>
	</header>
	<div class="content-db">
<?php if(Session::has('message')): ?>
<div class="row">
    <div class="alert alert-success">
        <div class="sb-msg"><i class="icon-thumbs-up"></i><?php echo e(Session::get('message')); ?></div>
    </div>
</div>
<?php endif; ?>
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
		<div class="row">
			<section id="teams" class="pd-bt-20">
				<div class="col-md-12 pd-lr-15 pd-bt-15">
					<div class="sec-content-db">
						<div class="div-content-db">
							<!-- Content goes here -->
							<form>
								<div class="panel panel-default">
									<div class="panel-heading">
										SemnasVerifier™
									</div>
									<div class="panel-body">	
										<?php echo Form::open(array('route' => 'semnas.store')); ?>

											<div class="form-group">
												<label class="control-label">Kode Penukaran : </label>
												<?php echo e(Form::text('code', null, array('class' => 'form-control'))); ?>

											</div>
											<div class="form-group">
												<input type="submit" name="submit" class="btn btn-info" />
											</div>
										<?php echo Form::close(); ?>

										<?php if(Session::has('semnas')): ?>
											<?php if(Session::get('semnas')->count()!=1): ?>
											Nggak ada di database
											<?php else: ?>
											Ada euy
											<?php endif; ?>
										<?php endif; ?>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</section>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>