<?php $__env->startSection('title', 'Vocomfest - News'); ?>

<?php $__env->startSection('body'); ?>
<section id="news-cover">
	<div class="overlay bk-overlay">
		<div class="news-container">
			<div class="news-desc">
				<p class="big" style="letter-spacing: 3px;">Gallery</p>
				<hr class="bl-line-sep">
			</div>
		</div>
	</div>
	<img src="<?php echo e(url('assets/img/event-cover.jpg')); ?>" class="cover-img">
</section>
<section id="news-body">
	<div class="container-fluid pd-bt-20">
		<div class="row pd-bt-20">
			<div class="col-md-12 pd-t-30">
				<?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<div class="col-md-3 gallery-content">
					<a href="<?php echo e(url('storage/gallery')); ?>/<?php echo e($key->path); ?>" data-rel="lightcase">
						<div class="gal-overlay">
							<div class="olay-content text-center">
								+
							</div>
						</div>
						<img src="<?php echo e(url('storage/gallery')); ?>/<?php echo e($key->path); ?>" alt="<?php echo e($key->text); ?>" class="cover-img">
					</a>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</div>
		</div>
	</div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>