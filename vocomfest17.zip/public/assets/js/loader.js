$(window).load(function() {
	$(".se-pre-con").fadeOut("slow");;
});